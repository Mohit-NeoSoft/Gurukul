export const environment = {
  baseUrl:'https://uat-gurukul.skfin.in/', 
  production: true
};
