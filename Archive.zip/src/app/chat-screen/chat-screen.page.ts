import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-screen',
  templateUrl: './chat-screen.page.html',
  styleUrls: ['./chat-screen.page.scss'],
})
export class ChatScreenPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
