import { ReplaceAmpPipe } from './replace-amp.pipe';

describe('ReplaceAmpPipe', () => {
  it('create an instance', () => {
    const pipe = new ReplaceAmpPipe();
    expect(pipe).toBeTruthy();
  });
});
