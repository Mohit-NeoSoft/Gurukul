import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-downloads',
  templateUrl: './course-downloads.page.html',
  styleUrls: ['./course-downloads.page.scss'],
})
export class CourseDownloadsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
